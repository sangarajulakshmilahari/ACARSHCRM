import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/config/db";
import { getAuthUser } from "@/app/api/lib/auth";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authUser = await getAuthUser(req);
    if (!authUser) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const projectId = Number(params.id);
    if (!projectId || Number.isNaN(projectId)) {
      return NextResponse.json({ error: "Invalid projectId" }, { status: 400 });
    }

    const pool = await getPool();
    const [rows]: any = await pool.query(
      `
      SELECT
        s.SOWId,
        s.ProjectId,
        s.SOWName,
        s.Client,
        s.FileName,
        s.EffectiveDate,
        s.StartDate,
        s.EndDate,
        s.NumberOfPositions,
        s.NumberOfResources,
        s.UploadedOn,
        s.ParseStatus,
        s.ParseMessage,
        s.VersionNo,
        s.Status
      FROM SOWMaster s
      WHERE s.ProjectId = ?
        AND s.IsActive = 1
        AND s.IsCurrent = 1
      ORDER BY s.VersionNo DESC
      LIMIT 1
      `,
      [projectId]
    );

    if (!rows?.length) {
      return NextResponse.json({ exists: false, sow: null });
    }

    const sow = rows[0];
    return NextResponse.json({
      exists: true,
      sow: {
        SOWId: sow.SOWId,
        ProjectId: sow.ProjectId,
        SOWName: sow.SOWName,
        Client: sow.Client,
        FileName: sow.FileName,
        EffectiveDate: sow.EffectiveDate,
        StartDate: sow.StartDate,
        EndDate: sow.EndDate,
        NumberOfPositions: Number(sow.NumberOfPositions || 0),
        NumberOfResources: Number(sow.NumberOfResources || 0),
        UploadedOn: sow.UploadedOn,
        ParseStatus: sow.ParseStatus,
        ParseMessage: sow.ParseMessage,
        VersionNo: Number(sow.VersionNo || 1),
        Status: sow.Status || "Active",
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Failed to fetch SOW" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authUser = await getAuthUser(req);
    if (!authUser) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const sowId = Number(params.id);
    if (!sowId || Number.isNaN(sowId)) {
      return NextResponse.json({ error: "Invalid sowId" }, { status: 400 });
    }

    const body = await req.json().catch(() => ({}));
    const status = body?.Status ? String(body.Status).trim() : null;
    const isActive =
      typeof body?.IsActive === "boolean" || typeof body?.IsActive === "number"
        ? Number(Boolean(body.IsActive))
        : null;

    if (status === null && isActive === null) {
      return NextResponse.json(
        { error: "Provide at least one field to update: Status or IsActive" },
        { status: 400 }
      );
    }

    const pool = await getPool();
    await pool.query(
      `
      UPDATE SOWMaster
      SET Status = COALESCE(?, Status),
          IsActive = COALESCE(?, IsActive)
      WHERE SOWId = ?
      `,
      [status, isActive, sowId]
    );

    const [rows]: any = await pool.query(
      `
      SELECT
        SOWId,
        ProjectId,
        SOWName,
        Client,
        FileName,
        EffectiveDate,
        StartDate,
        EndDate,
        NumberOfPositions,
        NumberOfResources,
        UploadedOn,
        ParseStatus,
        ParseMessage,
        VersionNo,
        Status,
        IsActive
      FROM SOWMaster
      WHERE SOWId = ?
      LIMIT 1
      `,
      [sowId]
    );

    return NextResponse.json(rows?.[0] || null);
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Failed to update SOW" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  let conn: any;
  try {
    const authUser = await getAuthUser(req);
    if (!authUser) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const sowId = Number(params.id);
    if (!sowId || Number.isNaN(sowId)) {
      return NextResponse.json({ error: "Invalid sowId" }, { status: 400 });
    }

    const pool = await getPool();
    conn = await pool.getConnection();

    await conn.beginTransaction();

    const [targetRows]: any = await conn.query(
      `SELECT SOWId, ProjectId, IsCurrent, VersionNo FROM SOWMaster WHERE SOWId = ? LIMIT 1`,
      [sowId]
    );
    const target = targetRows?.[0];
    if (!target) {
      await conn.rollback();
      return NextResponse.json({ error: "SOW not found" }, { status: 404 });
    }

    await conn.query(
      `
      UPDATE SOWMaster
      SET IsActive = 0,
          IsCurrent = 0,
          Status = 'Deleted'
      WHERE SOWId = ?
      `,
      [sowId]
    );

    if (Number(target.IsCurrent || 0) === 1) {
      const [fallbackRows]: any = await conn.query(
        `
        SELECT SOWId
        FROM SOWMaster
        WHERE ProjectId = ?
          AND IsActive = 1
          AND SOWId <> ?
        ORDER BY VersionNo DESC
        LIMIT 1
        `,
        [target.ProjectId, sowId]
      );
      const fallback = fallbackRows?.[0];
      if (fallback?.SOWId) {
        await conn.query(
          `UPDATE SOWMaster SET IsCurrent = 1, Status = 'Active' WHERE SOWId = ?`,
          [fallback.SOWId]
        );
      }
    }

    await conn.commit();
    return NextResponse.json({ success: true });
  } catch (error: any) {
    if (conn) {
      try {
        await conn.rollback();
      } catch {}
    }
    return NextResponse.json({ error: error?.message || "Failed to delete SOW" }, { status: 500 });
  } finally {
    if (conn) conn.release();
  }
}

