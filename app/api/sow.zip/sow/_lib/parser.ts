import mammoth from "mammoth";

export type ParsedSowResource = {
  resourceName: string;
  role: string;
  location: string | null;
  hourlyRate: number | null;
  startDate: string | null;
  endDate: string | null;
};

export type ParsedSowDocument = {
  sowName: string;
  client: string;
  effectiveDate: string | null;
  startDate: string | null;
  endDate: string | null;
  resources: ParsedSowResource[];
};

function normalizeSpaces(value: string): string {
  return value.replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ").trim();
}

function parseDateText(value?: string | null): string | null {
  if (!value) return null;
  const v = normalizeSpaces(String(value));
  if (!v) return null;

  const direct = new Date(v);
  if (!Number.isNaN(direct.getTime())) {
    return direct.toISOString().slice(0, 10);
  }

  const m = v.match(/(\d{1,2})[\-\/. ]([A-Za-z]{3,9}|\d{1,2})[\-\/. ](\d{2,4})/);
  if (!m) return null;

  const rawDay = Number(m[1]);
  const rawMonth = m[2];
  const rawYear = Number(m[3].length === 2 ? `20${m[3]}` : m[3]);

  const monthMap: Record<string, number> = {
    jan: 1,
    january: 1,
    feb: 2,
    february: 2,
    mar: 3,
    march: 3,
    apr: 4,
    april: 4,
    may: 5,
    jun: 6,
    june: 6,
    jul: 7,
    july: 7,
    aug: 8,
    august: 8,
    sep: 9,
    sept: 9,
    september: 9,
    oct: 10,
    october: 10,
    nov: 11,
    november: 11,
    dec: 12,
    december: 12,
  };

  const numericMonth = Number(rawMonth);
  const month = Number.isFinite(numericMonth) && numericMonth > 0
    ? numericMonth
    : monthMap[String(rawMonth).toLowerCase()] || 0;

  if (rawDay < 1 || rawDay > 31 || month < 1 || month > 12 || rawYear < 1900) return null;
  const iso = `${String(rawYear).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(rawDay).padStart(2, "0")}`;
  return iso;
}

function extractSingleValue(rawText: string, patterns: RegExp[]): string | null {
  for (const pattern of patterns) {
    const match = rawText.match(pattern);
    if (match?.[1]) {
      const value = normalizeSpaces(match[1]);
      if (value) return value;
    }
  }
  return null;
}

function parseHourlyRate(value?: string | null): number | null {
  if (!value) return null;
  const cleaned = String(value).replace(/[^0-9.\-]/g, "").trim();
  if (!cleaned) return null;
  const numeric = Number(cleaned);
  return Number.isFinite(numeric) ? numeric : null;
}

function pickColumn(cells: string[], index: number): string {
  if (index < 0 || index >= cells.length) return "";
  return normalizeSpaces(cells[index] || "");
}

function decodeHtmlEntities(value: string): string {
  return value
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'");
}

function stripHtml(value: string): string {
  return normalizeSpaces(decodeHtmlEntities(value.replace(/<[^>]*>/g, " ")));
}

function splitTextRowToCells(row: string): string[] {
  if (row.includes("\t")) {
    return row.split("\t").map(normalizeSpaces).filter(Boolean);
  }
  if (row.includes("|")) {
    return row.split("|").map(normalizeSpaces).filter(Boolean);
  }
  return row.split(/\s{2,}/).map(normalizeSpaces).filter(Boolean);
}

function extractTableRowsFromHtml(html: string): string[][] {
  const rows: string[][] = [];
  const trRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  let trMatch: RegExpExecArray | null;

  while ((trMatch = trRegex.exec(html)) !== null) {
    const rowHtml = trMatch[1] || "";
    const cellRegex = /<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi;
    const cells: string[] = [];
    let cellMatch: RegExpExecArray | null;

    while ((cellMatch = cellRegex.exec(rowHtml)) !== null) {
      const text = stripHtml(cellMatch[1] || "");
      if (text) cells.push(text);
    }

    if (cells.length > 0) rows.push(cells);
  }

  return rows;
}

function parseResourceRows(rows: string[][]): ParsedSowResource[] {
  let headerIndex = -1;
  let roleCol = -1;
  let resourceCol = -1;
  let locationCol = -1;
  let rateCol = -1;
  let startCol = -1;
  let endCol = -1;

  for (let i = 0; i < rows.length; i += 1) {
    const normalized = rows[i].map((c) => c.toLowerCase());
    const hasRole = normalized.some(
      (c) => c.includes("role") || c.includes("position") || c.includes("designation") || c.includes("title")
    );
    const hasResource = normalized.some(
      (c) => c.includes("resource") || c.includes("name") || c.includes("employee") || c.includes("consultant")
    );

    if (hasRole && hasResource) {
      headerIndex = i;
      roleCol = normalized.findIndex(
        (c) => c.includes("role") || c.includes("position") || c.includes("designation") || c.includes("title")
      );
      resourceCol = normalized.findIndex(
        (c) => c.includes("resource") || c.includes("name") || c.includes("employee") || c.includes("consultant")
      );
      locationCol = normalized.findIndex((c) => c.includes("location") || c.includes("onsite") || c.includes("offshore"));
      rateCol = normalized.findIndex((c) => c.includes("hourly") || c.includes("rate") || c.includes("billing") || c.includes("bill"));
      startCol = normalized.findIndex((c) => c.includes("start") || c.includes("from"));
      endCol = normalized.findIndex((c) => c.includes("end") || c.includes("to"));
      break;
    }
  }

  const resources: ParsedSowResource[] = [];
  const dataRows = headerIndex >= 0 ? rows.slice(headerIndex + 1) : rows;

  for (const cells of dataRows) {
    if (cells.length < 2) continue;
    if (/^appendix\s*\d+/i.test(cells[0] || "")) break;

    const role = pickColumn(cells, roleCol >= 0 ? roleCol : 1);
    const resourceName = pickColumn(cells, resourceCol >= 0 ? resourceCol : 0);
    if (!role || !resourceName) continue;

    resources.push({
      resourceName,
      role,
      location: pickColumn(cells, locationCol) || null,
      hourlyRate: parseHourlyRate(pickColumn(cells, rateCol)),
      startDate: parseDateText(pickColumn(cells, startCol)),
      endDate: parseDateText(pickColumn(cells, endCol)),
    });
  }

  return resources;
}

export async function parseSowDocxBuffer(fileBuffer: Buffer, fallbackFileName: string): Promise<ParsedSowDocument> {
  const mammothResult = await mammoth.extractRawText({ buffer: fileBuffer });
  const mammothHtmlResult = await mammoth.convertToHtml({ buffer: fileBuffer });
  const rawText = String(mammothResult?.value || "").replace(/\r/g, "");
  const rawHtml = String(mammothHtmlResult?.value || "");
  const lines = rawText
    .split("\n")
    .map((line) => line.trimEnd())
    .filter((line) => line.trim().length > 0);

  if (!lines.length) {
    throw new Error("Uploaded document appears to be empty or unreadable.");
  }

  const client = extractSingleValue(rawText, [
    /(?:^|\n)\s*Client\s*[:\-]\s*([^\n]+)/i,
    /(?:^|\n)\s*Customer\s*[:\-]\s*([^\n]+)/i,
    /(?:^|\n)\s*Client Name\s*[:\-]\s*([^\n]+)/i,
  ]) || "Unknown Client";

  const sowName = extractSingleValue(rawText, [
    /(?:^|\n)\s*SOW\s*Name\s*[:\-]\s*([^\n]+)/i,
    /(?:^|\n)\s*Statement\s+of\s+Work\s*[:\-]\s*([^\n]+)/i,
    /(?:^|\n)\s*Project\s*Name\s*[:\-]\s*([^\n]+)/i,
  ]) || fallbackFileName.replace(/\.docx$/i, "");

  const effectiveDate = parseDateText(
    extractSingleValue(rawText, [/(?:^|\n)\s*Effective\s*Date\s*[:\-]\s*([^\n]+)/i])
  );
  const startDate = parseDateText(
    extractSingleValue(rawText, [
      /(?:^|\n)\s*Start\s*Date\s*[:\-]\s*([^\n]+)/i,
      /(?:^|\n)\s*Commencement\s*Date\s*[:\-]\s*([^\n]+)/i,
    ])
  );
  const endDate = parseDateText(
    extractSingleValue(rawText, [
      /(?:^|\n)\s*End\s*Date\s*[:\-]\s*([^\n]+)/i,
      /(?:^|\n)\s*Completion\s*Date\s*[:\-]\s*([^\n]+)/i,
    ])
  );

  const tableRows = extractTableRowsFromHtml(rawHtml);
  let resources: ParsedSowResource[] = parseResourceRows(tableRows);

  if (resources.length === 0) {
    const appendixStartIndex = lines.findIndex((line) => /appendix\s*1/i.test(line) && /resourcing\s*plan/i.test(line));
    const resourceLines = appendixStartIndex >= 0 ? lines.slice(appendixStartIndex + 1) : lines;
    const textRows = resourceLines
      .map(splitTextRowToCells)
      .filter((cells) => cells.length > 1);
    resources = parseResourceRows(textRows);
  }

  if (resources.length === 0) {
    throw new Error("Unable to parse Appendix 1 (Resourcing Plan). Ensure table headers and rows are present.");
  }

  return {
    sowName,
    client,
    effectiveDate,
    startDate,
    endDate,
    resources,
  };
}

